# framework-web-element-core
Framework web element level core module
