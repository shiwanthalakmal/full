package com.framework.qa.webelementcore.elementbase.exception;

public class NullMemoryKeyException extends Exception {

    private static final long serialVersionUID = 1L;

    public NullMemoryKeyException(String message) {
        super(message);

    }
}
