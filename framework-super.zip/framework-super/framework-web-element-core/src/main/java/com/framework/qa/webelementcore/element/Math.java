package com.framework.qa.webelementcore.element;

import com.framework.qa.webelementcore.elementbase.core.BaseMath;
import org.openqa.selenium.By;
import org.openqa.selenium.remote.RemoteWebDriver;

public class Math extends BaseMath {
    public Math(RemoteWebDriver driver, By locator) {
        super(driver, locator);

    }
}
